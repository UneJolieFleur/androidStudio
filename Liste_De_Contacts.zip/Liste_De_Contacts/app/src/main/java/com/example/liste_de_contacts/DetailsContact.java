package com.example.liste_de_contacts;
import android.content.ContentUris;
import android.content.Context;
import android.content.Intent;
import android.net.Uri;
import android.os.Bundle;
import android.provider.ContactsContract;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.TextView;

import com.example.liste_de_contacts.R;
import com.google.android.material.bottomsheet.BottomSheetDialogFragment;

import androidx.annotation.Nullable;


public class DetailsContact extends BottomSheetDialogFragment {

    @Nullable
    @Override
    public View onCreateView(LayoutInflater inflater, @Nullable ViewGroup container, @Nullable Bundle savedInstanceState) {
        View v = inflater.inflate(R.layout.modal_detail,container, false);
        TextView t1 = (TextView) v.findViewById(R.id.modal_text_view_nom);
        TextView t2 = (TextView) v.findViewById(R.id.modal_text_view_numero);
        ImageView image1 = (ImageView) v.findViewById(R.id.image_detail);

        com.google.android.material.floatingactionbutton.FloatingActionButton button = v.findViewById(R.id.floatingActionButtonEdit);
        button.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent editIntent = new Intent(Intent.ACTION_EDIT);
                Uri editUri = ContentUris.withAppendedId(ContactsContract.Contacts.CONTENT_URI,Long.parseLong(MainActivity.clickedContact.getId()));
                editIntent.setData(editUri);
                startActivity(editIntent);

            }
        });

        t1.setText(MainActivity.clickedContact.getNom());
        t2.setText(MainActivity.clickedContact.getNumero());

        try {
            image1.setImageURI(Uri.parse(MainActivity.clickedContact.getPhoto()));
        }catch(Exception e){
            Log.e("erreur image", e.getMessage());
        }




        return v;


    }

    public interface DetailsContactListener{


    }
}