package com.example.liste_de_contacts;

public class Contacts {
    private String id;
    private String nom;
    private String numero;
    private String photo;

    public Contacts(String id, String nom,String numero,String photo){
        this.id = id;
        this.nom = nom;
        this.numero = numero;
        this.photo = photo;
    }

    public String getId() {
        return id;
    }

    public void setId(String id) {
        this.id = id;
    }

    public String getNom() {
        return nom;
    }

    public void setNom(String nom) {
        this.nom = nom;
    }

    public String getNumero() {
        return numero;
    }

    public void setNumero(String numero) {
        this.numero = numero;
    }

    public String getPhoto() {
        return photo;
    }

    public void setPhoto(String photo) {
        this.photo = photo;
    }
}