package com.example.liste_de_contacts;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.app.ActivityCompat;
import androidx.core.content.ContextCompat;

import android.Manifest;
import android.content.DialogInterface;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.database.Cursor;
import android.os.Bundle;
import android.provider.ContactsContract;
import android.util.Log;
import android.view.View;
import android.widget.AdapterView;
import android.widget.Button;
import android.widget.ListView;
import android.widget.SimpleAdapter;
import android.widget.SimpleCursorAdapter;
import android.widget.Toast;

import java.util.ArrayList;
import java.util.List;

public class MainActivity extends AppCompatActivity {
    public static Contacts clickedContact;
    ListView l1;
    private int PERMISSION_CODE = 42;

    @Override
    protected void onCreate(Bundle savedInstanceState) {

        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        l1 = findViewById(R.id.listView);

        if(ContextCompat.checkSelfPermission(MainActivity.this, Manifest.permission.READ_CONTACTS)== PackageManager.PERMISSION_GRANTED){
            Toast.makeText(MainActivity.this,"La permission est deja acordée",Toast.LENGTH_SHORT).show();


        }else {
            requestReadContacts();
        }

        final ArrayList<Contacts> listContacts = afficherContacts();

        l1.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            @Override
            public void onItemClick(AdapterView<?> parent, View view, int position, long id) {

                clickedContact = listContacts.get(position);

                DetailsContact detail = new DetailsContact();
                detail.show(getSupportFragmentManager(), "détail d'un contact");

            }
        });

    }

    private ArrayList<Contacts> afficherContacts(){
        ArrayList<Contacts> listeContacts = new ArrayList<Contacts>();
        Cursor curseur = getContentResolver().query(ContactsContract.CommonDataKinds.Phone.CONTENT_URI,null,null,null,null);

        startManagingCursor(curseur);


        String[] from = {ContactsContract.CommonDataKinds.Phone.DISPLAY_NAME, ContactsContract.CommonDataKinds.Phone.NUMBER, ContactsContract.CommonDataKinds.Phone._ID};

        int [] to ={android.R.id.text1};

        SimpleCursorAdapter simpleCursorAdapter = new SimpleCursorAdapter(this,android.R.layout.simple_list_item_2,curseur,from,to);
        l1.setAdapter(simpleCursorAdapter);
        l1.setChoiceMode(ListView.CHOICE_MODE_MULTIPLE);
        curseur.moveToFirst();
        do{
            Contacts c = new Contacts(curseur.getString(curseur.getColumnIndex(ContactsContract.CommonDataKinds.Phone.CONTACT_ID)),
                    curseur.getString(curseur.getColumnIndex(ContactsContract.CommonDataKinds.Phone.DISPLAY_NAME)),
                    curseur.getString(curseur.getColumnIndex(ContactsContract.CommonDataKinds.Phone.NUMBER)),
                    curseur.getString(curseur.getColumnIndex(ContactsContract.CommonDataKinds.Phone.PHOTO_URI)));
            listeContacts.add(c);
            curseur.moveToNext();
        }while(!curseur.isAfterLast());
        return listeContacts;
    }


    private void requestReadContacts(){
        if(ActivityCompat.shouldShowRequestPermissionRationale( this,Manifest.permission.READ_CONTACTS)){
            new AlertDialog.Builder(this).setTitle("Permission nécessaire")
                    .setMessage("Souhaitez vous que l'application accèder à votre liste de contacts ?")
                    .setPositiveButton("accepter", new DialogInterface.OnClickListener() {
                        @Override
                        public void onClick(DialogInterface dialog, int which) {
                            ActivityCompat.requestPermissions(MainActivity.this,new String[]{Manifest.permission.READ_CONTACTS},PERMISSION_CODE);
                        }
                    })
                    .setNegativeButton("annuler", new DialogInterface.OnClickListener() {
                        @Override
                        public void onClick(DialogInterface dialog, int which) {
                            dialog.dismiss();
                        }
                    }).create().show();
        }else{
            ActivityCompat.requestPermissions(MainActivity.this,new String[]{Manifest.permission.READ_CONTACTS},PERMISSION_CODE);
        }
    }


    @Override
    public void onRequestPermissionsResult(int requestCode, @NonNull String[] permissions, @NonNull int[] grantResults) {
        if(requestCode == PERMISSION_CODE){
            if(grantResults.length>0 && grantResults[0] == PackageManager.PERMISSION_GRANTED){
                Toast.makeText(this,"Permission ajouté ",Toast.LENGTH_SHORT).show();
            }else{
                Toast.makeText(this,"Permission refusé ",Toast.LENGTH_SHORT).show();
            }
        }
    }




}
